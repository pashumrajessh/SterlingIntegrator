SAMPLE FILES FOR THE 837 TO 835 STERLING MAP EDITOR HANDS-ON LAB
Companion to: 837 to 835 End-to-End: Building It in Sterling Map Editor

These files are the exact sample records used throughout the guide,
saved as plain text so you can load them directly instead of retyping
or copy-pasting from the document. Keep them open or saved on the PC
running Map Editor while you work through Exercises A through D.

WHAT EACH FILE IS FOR

837P_Sample_Claim.txt
  The fictional inbound 837P claim used throughout the guide. Use this
  as your Test Map / SI Map Test input when testing the Inbound 837
  5010 Map in Exercise A, and again as the file you submit or run
  manually for the end-to-end test in Exercise B, step 7.

CanonicalClaim_Expected_Output_Reference.txt
  The field-by-field values your Inbound 837 5010 Map should produce
  when it processes 837P_Sample_Claim.txt. Use this in Exercise A to
  check your own Test Map output — and again in Exercise B, step 8,
  to confirm the finished business process produced the same record.
  This is a reference to compare against, not a file you load into
  Map Editor directly (see the note inside the file).

CanonicalPayment_Sample_Input_Reference.txt
  The fictional adjudication result described in the guide, shown the
  same way as the file above. Use it to check your own test input and
  output values field by field when you build the Outbound 835 5010
  Map in Exercise C.

CanonicalPayment_Sample_Input.xml
  A complete, ready-to-use XML version of the same adjudication result,
  with both service lines fully populated. Use this directly as your
  Test Map / SI Map Test input in Exercise C if you chose XML (rather
  than Positional) as the input format for your Outbound 835 5010 Map.
  If you built a Positional layout instead, use the reference file
  above to check your values by hand, since the exact byte layout
  depends on the field widths you defined yourself.

835_Sample_Remittance.txt
  The fictional outbound 835 remittance the guide builds toward. Use
  this in Exercise C to compare against your own map's test output,
  segment for segment, and again in Exercise D to confirm the finished
  business process produces a matching remittance.

A NOTE ON THE CANONICAL (INTERNAL) RECORDS

The guide lets you build the Canonical Claim and Canonical Payment
layers as either a Positional layout or an XML format — both work the
same way once your type tree and rules are built. Because a Positional
layout's exact byte positions depend on the field widths you define
yourself in Map Editor, the two "_Reference.txt" files above are meant
for checking your results by eye rather than for loading in directly.
The two X12 files (837P and 835) and the Canonical Payment XML file are
all literal, ready-to-use test files regardless of which choice you
made for the canonical layer.

All data in these files — provider name, payer name, patient name,
member ID, NPI, and claim amounts — is fictional and used purely for
illustration.
